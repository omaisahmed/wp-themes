<?php
/**
 * This file's content is located in /lib/templates/structure/sidebar-secondary.php and should
 * only be overwritten via your child theme.
 *
 * We strongly recommend to read the Beans documentation to find out more about
 * how to customize the Beans theme.
 *
 * @author Beans
 * @link   https://www.getbeans.io
 * @package Beans\Framework
 */

beans_load_default_template( __FILE__ );
