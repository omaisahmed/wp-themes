<?php
/**
 * The primary sidebar is set in sidebar-primary.php so that we can have control over the layout. Do
 * not overwrite this file.
 *
 * @author Beans
 * @link   https://www.getbeans.io
 * @package Beans\Framework
 */

// See sidebar-primary.php.
