<?php get_header(); ?>
<div class="container">
<div id="content_holder">
     <div class="default_content_alignbx fullwidth">  
			<?php woocommerce_content(); ?>
    </div><!-- default_content_alignbx-->   
</div><!-- .content_holder --> 
</div><!-- .container -->     
<?php get_footer(); ?>